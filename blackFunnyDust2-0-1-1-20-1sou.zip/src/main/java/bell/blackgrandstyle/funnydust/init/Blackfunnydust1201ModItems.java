package bell.blackgrandstyle.funnydust.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import bell.blackgrandstyle.funnydust.item.DustItem;
import bell.blackgrandstyle.funnydust.item.AlmostBrokeDustItem;
import bell.blackgrandstyle.funnydust.Blackfunnydust1201Mod;

public class Blackfunnydust1201ModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, Blackfunnydust1201Mod.MODID);
	public static final RegistryObject<Item> DUST = REGISTRY.register("dust", () -> new DustItem());
	public static final RegistryObject<Item> ALMOST_BROKE_DUST = REGISTRY.register("almost_broke_dust", () -> new AlmostBrokeDustItem());
}
