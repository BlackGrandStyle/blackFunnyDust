
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package bell.blackgrandstyle.funnydust.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import bell.blackgrandstyle.funnydust.Blackfunnydust1201Mod;

public class Blackfunnydust1201ModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, Blackfunnydust1201Mod.MODID);
	public static final RegistryObject<SoundEvent> DUST_SOUNDS = REGISTRY.register("dust_sounds", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("blackfunnydust1_20_1", "dust_sounds")));
}
