
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package bell.blackgrandstyle.funnydust.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import bell.blackgrandstyle.funnydust.Blackfunnydust1201Mod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class Blackfunnydust1201ModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, Blackfunnydust1201Mod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {

		if (tabData.getTabKey() == CreativeModeTabs.COLORED_BLOCKS) {
			tabData.accept(Blackfunnydust1201ModItems.DUST.get());
			tabData.accept(Blackfunnydust1201ModItems.ALMOST_BROKE_DUST.get());
		}
	}
}
