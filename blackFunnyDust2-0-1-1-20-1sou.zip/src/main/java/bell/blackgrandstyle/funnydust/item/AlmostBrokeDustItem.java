
package bell.blackgrandstyle.funnydust.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class AlmostBrokeDustItem extends Item {
	public AlmostBrokeDustItem() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
	}
}
